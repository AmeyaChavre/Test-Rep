

let isPrime = function (n) {
 
    if (n == 2)
        return true;
    for (i = 2; i < Math.sqrt(n); i++) {
        if (n % i == 0)
            return false;
    }
    return true;
};

let getLargestPrimeFactor = function (n) {
  

    var i = 2;
    while (i <= n) {
        if (n % i == 0) {
            n /= i;
        } else {
            i++;
        }
    }
    return i;

};


